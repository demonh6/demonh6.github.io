/* Stub function as a placeholder */  
/* To get functionality user must run INSTALL script in 
   utilities/io/checkpoint/hdf5 */
void read_blocks_hdf5_r4(void) {
}
