#include <stdio.h>

extern void* c_amr_get_pointer(char*);

#include "underscore.h"

char *output_dir;
output_dir = (char *) c_amr_get_pointer("output_dir");
output_dir[0] = output_dir[0];


