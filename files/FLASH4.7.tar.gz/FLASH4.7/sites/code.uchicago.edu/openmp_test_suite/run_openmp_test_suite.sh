#!/bin/bash

. env.sh intel
./flashTest.py -v -f jobs/mainBatch
